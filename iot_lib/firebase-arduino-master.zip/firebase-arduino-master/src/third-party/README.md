These are packages that we depend upon. They may need to be trimmed, all .cpp
files in them will be compiled by the arduino IDE.
